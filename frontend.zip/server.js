const http = require('http');
const fs   = require('fs');
const path = require('path');

const port = process.env.PORT || 8080;
const root = __dirname;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.json': 'application/json',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.ico':  'image/x-icon',
};

http.createServer((req, res) => {
  const url  = req.url.split('?')[0].split('#')[0];
  const file = path.join(root, url);
  if (url !== '/' && fs.existsSync(file) && fs.statSync(file).isFile()) {
    const mime = MIME[path.extname(file)] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': url.startsWith('/assets/') ? 'max-age=31536000,immutable' : 'no-cache' });
    fs.createReadStream(file).pipe(res);
  } else {
    // SPA fallback
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
    fs.createReadStream(path.join(root, 'index.html')).pipe(res);
  }
}).listen(port, () => console.log('Frontend serving on port', port));
